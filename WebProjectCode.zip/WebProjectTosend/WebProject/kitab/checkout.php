<?php
require_once 'config.php';

$cart = $_SESSION['cart'] ?? [];
if (empty($cart)) { header('Location: cart.php'); exit; }

$total  = array_sum(array_map(fn($i) => $i['price'] * $i['qty'], $cart));
$msg    = '';
$placed = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    $name  = trim($conn->real_escape_string($_POST['name']    ?? ''));
    $email = trim($conn->real_escape_string($_POST['email']   ?? ''));
    $phone = trim($conn->real_escape_string($_POST['phone']   ?? ''));
    $addr  = trim($conn->real_escape_string($_POST['address'] ?? ''));

    if ($name && $email) {
        $oid = next_order_id($conn);

        // Insert one row per book into Orders table
        $stmt = $conn->prepare("INSERT INTO Orders (order_id, book_id, quantity, total_price) VALUES (?,?,?,?)");
        foreach ($cart as $pid => $item) {
            $line_total = $item['price'] * $item['qty'];
            $stmt->bind_param('iiid', $oid, $pid, $item['qty'], $line_total);
            $stmt->execute();
            // Decrease stock
            $conn->query("UPDATE Books SET stock = stock - {$item['qty']} WHERE book_id = $pid AND stock >= {$item['qty']}");
        }
        $stmt->close();

        // Save customer info in CustomerOrders
        $s2 = $conn->prepare("INSERT INTO CustomerOrders (order_id,customer_name,customer_email,customer_phone,customer_address,total_amount) VALUES(?,?,?,?,?,?)");
        $s2->bind_param('issssd', $oid, $name, $email, $phone, $addr, $total);
        $s2->execute();
        $s2->close();

        // Save purchase history in cookie
        cookie_add_history(array_keys($cart));

        // Clear cart
        $_SESSION['cart'] = [];
        $placed = true;
        $msg = '<div class="alert alert-success">✓ Order <strong>#' . $oid . '</strong> confirmed! Thank you, <strong>' . htmlspecialchars($name) . '</strong>.</div>';
    } else {
        $msg = '<div class="alert alert-danger">Please fill in your Name and Email.</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Checkout — Kitab Store</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<nav class="navbar">
  <a href="index.php" class="nav-logo"><span class="logo-icon">📚</span> Kitab Store</a>
  <ul class="nav-links">
    <li><a href="index.php">Books</a></li>
    <li><a href="contact.php">Contact</a></li>
    <li><a href="cart.php" class="nav-cart">🛒 Cart (<?= cart_count() ?>)</a></li>
  </ul>
</nav>

<div class="checkout-wrap">
  <h1>Checkout</h1>
  <?= $msg ?>

  <?php if ($placed): ?>
    <a href="index.php" class="btn-brown" style="margin-top:14px;display:inline-block;">← Back to Books</a>

  <?php else: ?>

  <!-- Order Summary -->
  <div class="order-summary-box" style="background:var(--cream);border:1px solid var(--pale-teal);border-top:3px solid var(--teal);padding:22px;margin-bottom:24px;border-radius:3px;">
    <h3 style="font-family:'Playfair Display',serif;font-size:1.1rem;margin-bottom:14px;">Order Summary</h3>
    <?php foreach ($cart as $item): ?>
    <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--pale-teal);font-size:0.88rem;">
      <span><?= htmlspecialchars($item['name']) ?> × <?= $item['qty'] ?></span>
      <span>SAR <?= number_format($item['price'] * $item['qty'], 2) ?></span>
    </div>
    <?php endforeach; ?>
    <div style="display:flex;justify-content:space-between;padding:12px 0;font-weight:700;font-size:1rem;color:var(--teal);">
      <span>Total</span>
      <span>SAR <?= number_format($total, 2) ?></span>
    </div>
  </div>

  <!-- Customer Form -->
  <form method="post">
    <div class="form-grp">
      <label>Full Name *</label>
      <input type="text" name="name" placeholder="e.g. Ahmed Al-Rashidi" required value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
    </div>
    <div class="form-grp">
      <label>Email Address *</label>
      <input type="email" name="email" placeholder="ahmed@example.com" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
    </div>
    <div class="form-grp">
      <label>Phone Number</label>
      <input type="tel" name="phone" placeholder="5X XXX XXXX"
        pattern="5[0-9]{8}"
        maxlength="9"
        title="Phone number must start with 5 followed by 8 digits (e.g. 512345678)"
        value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>"
        oninput="this.value=this.value.replace(/[^0-9]/g,'').slice(0,9)">
    </div>
    <div class="form-grp">
      <label>Shipping Address</label>
      <textarea name="address" rows="3" placeholder="City, District, Street..."><?= htmlspecialchars($_POST['address'] ?? '') ?></textarea>
    </div>
    <div style="display:flex;gap:12px;margin-top:10px;">
      <a href="cart.php" class="btn-outline-brown">← Back to Cart</a>
      <button type="submit" name="place_order" class="btn-brown">Place Order 📚</button>
    </div>
  </form>

  <?php endif; ?>
</div>

<footer><p>© <?= date('Y') ?> <span>Kitab Store</span> — Books for Every Mind · Saudi Arabia</p></footer>
</body>
</html>
