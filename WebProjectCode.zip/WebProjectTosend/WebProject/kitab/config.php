<?php
// ── Database connection ───────────────────────────────────────
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');          // Change if your MySQL has a password
define('DB_NAME', 'book_store');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) die('DB connection failed: ' . $conn->connect_error);
$conn->set_charset('utf8mb4');

// ── Session ───────────────────────────────────────────────────
if (session_status() === PHP_SESSION_NONE) session_start();

// ── Cookie: purchase history ──────────────────────────────────
// Cookie name: kitab_history  →  comma-separated book_id values, 365-day expiry
function cookie_get_history(): array {
    if (empty($_COOKIE['kitab_history'])) return [];
    return array_values(array_filter(array_map('intval', explode(',', $_COOKIE['kitab_history']))));
}
function cookie_add_history(array $ids): void {
    $merged = array_values(array_unique(array_merge(cookie_get_history(), array_map('intval', $ids))));
    setcookie('kitab_history', implode(',', $merged), time() + 365 * 86400, '/', '', false, true);
}

// ── Cart count (SESSION) ──────────────────────────────────────
function cart_count(): int {
    $n = 0;
    if (!empty($_SESSION['cart'])) foreach ($_SESSION['cart'] as $i) $n += (int)$i['qty'];
    return $n;
}

// ── Next order_id ─────────────────────────────────────────────
function next_order_id($conn): int {
    $r = $conn->query("SELECT COALESCE(MAX(order_id),0)+1 AS nxt FROM Orders")->fetch_assoc();
    return (int)$r['nxt'];
}

// ── Category styling ──────────────────────────────────────────
const CAT_CSS   = ['Adult' => 'adult', 'Children' => 'children',
                   'Fiction' => 'fiction', 'History' => 'history',
                   'Educational' => 'educational'];
const CAT_EMOJI = ['Adult' => '📖', 'Children' => '🧒',
                   'Fiction' => '📖', 'History' => '🏛', 'Educational' => '🎓'];
?>
