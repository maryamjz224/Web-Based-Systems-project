<?php
require_once 'config.php';

$filter = isset($_GET['cat']) ? $conn->real_escape_string(trim($_GET['cat'])) : '';
$sql    = 'SELECT * FROM Books';
if ($filter) $sql .= " WHERE category='$filter'";
$sql   .= ' ORDER BY book_id ASC';
$books  = $conn->query($sql)->fetch_all(MYSQLI_ASSOC);

$cats   = $conn->query("SELECT DISTINCT category FROM Books ORDER BY category")->fetch_all(MYSQLI_ASSOC);

// Past purchases cookie
$hist_ids  = cookie_get_history();
$past_books = [];
if ($hist_ids) {
    $in = implode(',', $hist_ids);
    $past_books = $conn->query("SELECT book_id,title,image,category FROM Books WHERE book_id IN($in) ORDER BY book_id DESC LIMIT 4")->fetch_all(MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kitab Store — Books for Every Mind</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <a href="index.php" class="nav-logo"><span class="logo-icon">📚</span> Kitab Store</a>
  <ul class="nav-links">
    <li><a href="index.php">Books</a></li>
    <li><a href="contact.php">Contact</a></li>
    <li><a href="admin/login.php" target="_blank">↗ login</a></li>
    <li><a href="cart.php" class="nav-cart">🛒 Cart (<?= cart_count() ?>)</a></li>
  </ul>
</nav>

<!-- HERO -->
<section class="hero">
  <div class="hero-text">
    <div class="hero-eyebrow">Your Bookstore · Saudi Arabia</div>
    <h1>Books That <em>Inspire,</em><br>Stories That Last</h1>
    <p>Explore our curated collection for Adults and Children. Handpicked titles waiting for you.</p>
    <div class="hero-btns">
      <a href="#collection" class="btn-cream">Browse Collection</a>
      <a href="contact.php" class="btn-outline-cream">Visit Us</a>
    </div>
  </div>
  <div class="hero-shelf">
    <div class="spine spine-Chlidern"><div class="spine-title">James and the Giant Peach</div><div class="spine-cat">Children</div></div>
    <div class="spine spine-fiction"><div class="spine-title">The Little Prince</div><div class="spine-cat">Adult</div></div>
    <div class="spine spine-Chlidern"><div class="spine-title">Heidi</div><div class="spine-cat">Children</div></div>
  </div>
</section>



<!-- Past Purchases (cookie) -->
<?php if ($past_books): ?>
<div style="padding:16px 60px;background:var(--cream);border-top:2px solid var(--pale-teal);border-bottom:2px solid var(--pale-teal);margin-bottom:6px;">
  <div style="font-size:0.72rem;font-weight:700;letter-spacing:0.2em;text-transform:uppercase;color:var(--brown);margin-bottom:10px;">📖 Previously Purchased</div>
  <div style="display:flex;gap:14px;flex-wrap:wrap;">
    <?php foreach ($past_books as $pb):
      $img = 'images/' . $pb['image'];
      $cls = CAT_CSS[$pb['category']] ?? 'adult';
    ?>
    <a href="product.php?id=<?= $pb['book_id'] ?>"
       style="display:flex;align-items:center;gap:10px;background:var(--white);border:1px solid var(--pale-teal);padding:8px 14px;border-radius:3px;text-decoration:none;color:var(--dark);font-size:0.85rem;font-weight:600;">
      <?php if (file_exists($img) && $pb['image'] !== 'default.jpg'): ?>
        <img src="<?= $img ?>" style="width:32px;height:42px;object-fit:cover;border-radius:2px;" alt="">
      <?php else: ?>
        <span style="font-size:1.5rem;"><?= CAT_EMOJI[$pb['category']] ?? '📚' ?></span>
      <?php endif; ?>
      <?= htmlspecialchars($pb['title']) ?>
    </a>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<!-- COLLECTION -->
<div id="collection">
  <div class="section-hd">
    <span class="eyebrow">Our Collection</span>
    <h2>Handpicked <em>Titles</em> for You</h2>
  </div>

  <!-- Category Tabs -->
  <div class="cat-tabs">
    <a href="index.php" class="cat-tab <?= !$filter ? 'active' : '' ?>">All Books</a>
    <?php foreach ($cats as $c):
      $slug  = $c['category'];
      $emoji = CAT_EMOJI[$slug] ?? '📚';
    ?>
    <a href="index.php?cat=<?= urlencode($slug) ?>"
       class="cat-tab <?= $filter === $slug ? 'active' : '' ?>">
      <?= $emoji . ' ' . htmlspecialchars($slug) ?>
    </a>
    <?php endforeach; ?>
  </div>

  <!-- Books Grid -->
  <div class="books-section">
    <?php if (empty($books)): ?>
      <p style="text-align:center;padding:50px;color:var(--gray);">
        No books found. <a href="admin/login.php" style="color:var(--brown);">Admin: Add books →</a>
      </p>
    <?php else: ?>
    <div class="books-grid">
      <?php foreach ($books as $b):
        $cls   = CAT_CSS[$b['category']]   ?? 'adult';
        $emoji = CAT_EMOJI[$b['category']] ?? '📚';
        $img   = 'images/' . $b['image'];
      ?>
      <a href="product.php?id=<?= $b['book_id'] ?>" class="book-card">
        <div class="book-cover cover-<?= $cls ?>">
          <?php if (file_exists($img) && $b['image'] !== 'default.jpg'): ?>
            <img src="<?= $img ?>" alt="<?= htmlspecialchars($b['title']) ?>">
          <?php else: ?>
            <span class="book-emoji"><?= $emoji ?></span>
          <?php endif; ?>
        </div>
        <div class="book-body">
          <span class="cat-badge cat-<?= $cls ?>"><?= htmlspecialchars($b['category']) ?></span>
          <h3><?= htmlspecialchars($b['title']) ?></h3>
          <div class="book-author">by <?= htmlspecialchars($b['author']) ?></div>
          <div class="price-row">
            <div class="book-price">SAR <?= number_format($b['price'], 0) ?> <span>/copy</span></div>
            <span class="btn-add">Add to Cart</span>
          </div>
        </div>
      </a>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</div>

<footer>
  <p>© <?= date('Y') ?> <span>Kitab Store</span> — Books for Every Mind · Saudi Arabia</p>
</footer>
</body>
</html>
