<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contact — Kitab Store</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<nav class="navbar">
  <a href="index.php" class="nav-logo"><span class="logo-icon">📚</span> Kitab Store</a>
  <ul class="nav-links">
    <li><a href="index.php">Books</a></li>
    <li><a href="contact.php">Contact</a></li>
    <li><a href="cart.php" class="nav-cart">🛒 Cart (<?= cart_count() ?>)</a></li>
  </ul>
</nav>

<div style="padding:55px 60px 20px;">
  <span style="font-size:0.7rem;font-weight:700;letter-spacing:0.28em;text-transform:uppercase;color:var(--brown-light);display:block;margin-bottom:10px;">Find Us</span>
  <h2 style="font-family:'Playfair Display',serif;font-size:2.6rem;font-weight:700;">Contact <em style="font-style:italic;color:var(--brown-mid);">Kitab Store</em></h2>
</div>

<div class="contact-wrap">
  <div class="contact-info">
    <p style="color:var(--gray);line-height:1.85;margin-bottom:30px;font-size:0.92rem;">
      We welcome you to visit our bookstore or get in touch for orders, recommendations, and events. Our team of book lovers is always happy to help.
    </p>

    <div class="contact-detail">
      <div class="c-icon">📞</div>
      <div><strong>Phone & WhatsApp</strong><p>+966 11 XXX XXXX<br>+966 5X XXX XXXX</p></div>
    </div>
    <div class="contact-detail">
      <div class="c-icon">✉</div>
      <div><strong>Email</strong><p>hello@kitabstore.sa<br>orders@kitabstore.sa</p></div>
    </div>
    <div class="contact-detail">
      <div class="c-icon">🕐</div>
      <div><strong>Opening Hours</strong><p>Sat – Wed: 9:00 AM – 10:00 PM<br>Thu – Fri: 12:00 PM – 12:00 AM</p></div>
    </div>

    <!-- Send Message form -->
    <div style="background:var(--cream);border:1px solid var(--cream-deep);border-top:3px solid var(--brown);padding:22px;margin-top:10px;border-radius:3px;">
      <h3 style="font-family:'Playfair Display',serif;font-size:1.1rem;font-weight:600;margin-bottom:16px;">Send a Message</h3>
      <?php
      $cmsg = '';
      if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_msg'])) {
          $mname  = htmlspecialchars(trim($_POST['msg_name']  ?? ''));
          $memail = htmlspecialchars(trim($_POST['msg_email'] ?? ''));
          $mtext  = htmlspecialchars(trim($_POST['msg_text']  ?? ''));
          if ($mname && $memail && $mtext) {
              $cmsg = '<div class="alert alert-success">✓ Thank you, ' . $mname . '! We\'ll reply to ' . $memail . ' shortly.</div>';
          } else {
              $cmsg = '<div class="alert alert-danger">Please fill in all fields.</div>';
          }
      }
      echo $cmsg;
      ?>
      <?php if (!str_contains($cmsg, 'Thank you')): ?>
      <form method="post">
        <div class="form-grp">
          <label>Your Name *</label>
          <input type="text" name="msg_name" placeholder="e.g. Sara Al-Otaibi" required>
        </div>
        <div class="form-grp">
          <label>Email *</label>
          <input type="email" name="msg_email" placeholder="sara@example.com" required>
        </div>
        <div class="form-grp">
          <label>Message *</label>
          <textarea name="msg_text" rows="3" placeholder="Ask about a book, event, or order..." required></textarea>
        </div>
        <button type="submit" name="send_msg" class="btn-brown" style="width:100%;">Send Message 📚</button>
      </form>
      <?php endif; ?>
    </div>
  </div>

  <div style="flex:1;min-width:280px;">
    <div class="map-box">
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3624.6537168560587!2d46.6752!3d24.6877!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjTCsDQxJzE1LjciTiA0NsKwNDAnMzAuNyJF!5e0!3m2!1sen!2ssa!4v1620000000000"
        width="100%" height="380" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    </div>
    <div style="margin-top:18px;background:var(--cream);border:1px solid var(--cream-deep);padding:20px;border-radius:3px;">
      <h4 style="font-family:'Playfair Display',serif;font-size:1.05rem;margin-bottom:14px;">Browse by Category</h4>
      <div style="display:flex;flex-wrap:wrap;gap:8px;">
        <a href="index.php?cat=Adult"    style="background:var(--teal);color:#fff;padding:6px 16px;border-radius:3px;font-size:0.76rem;font-weight:700;letter-spacing:0.1em;text-decoration:none;text-transform:uppercase;">📖 Adult</a>
        <a href="index.php?cat=Children" style="background:var(--gold,#c2a56d);color:var(--dark);padding:6px 16px;border-radius:3px;font-size:0.76rem;font-weight:700;letter-spacing:0.1em;text-decoration:none;text-transform:uppercase;">🧒 Children</a>
      </div>
    </div>
  </div>
</div>

<footer><p>© <?= date('Y') ?> <span>Kitab Store</span> — Books for Every Mind · Saudi Arabia</p></footer>
</body>
</html>
