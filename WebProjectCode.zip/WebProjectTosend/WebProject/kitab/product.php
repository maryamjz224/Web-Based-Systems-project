<?php
require_once 'config.php';

$id = (int)($_GET['id'] ?? 0);
$b  = $conn->query("SELECT * FROM Books WHERE book_id=$id")->fetch_assoc();
if (!$b) { header('Location: index.php'); exit; }

$cls   = CAT_CSS[$b['category']]   ?? 'adult';
$emoji = CAT_EMOJI[$b['category']] ?? '📚';
$msg   = '';

// Add to cart (SESSION)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_cart'])) {
    $qty = max(1, (int)$_POST['quantity']);
    if ($qty > $b['stock']) {
        $msg = '<div class="alert alert-danger">Only ' . $b['stock'] . ' copies in stock.</div>';
    } else {
        if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
        if (isset($_SESSION['cart'][$id])) $_SESSION['cart'][$id]['qty'] += $qty;
        else $_SESSION['cart'][$id] = [
            'id'    => $b['book_id'],
            'name'  => $b['title'],
            'price' => $b['price'],
            'image' => $b['image'],
            'qty'   => $qty
        ];
        $msg = '<div class="alert alert-success">✓ Added to cart! <a href="cart.php" style="color:var(--brown);font-weight:700;">View Cart →</a></div>';
    }
}

$img = 'images/' . $b['image'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($b['title']) ?> — Kitab Store</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<nav class="navbar">
  <a href="index.php" class="nav-logo"><span class="logo-icon">📚</span> Kitab Store</a>
  <ul class="nav-links">
    <li><a href="index.php">Books</a></li>
    <li><a href="contact.php">Contact</a></li>
    <li><a href="cart.php" class="nav-cart">🛒 Cart (<?= cart_count() ?>)</a></li>
  </ul>
</nav>

<div style="max-width:1080px;margin:40px auto;padding:0 40px;">
  <div style="display:flex;gap:40px;align-items:flex-start;flex-wrap:wrap;margin-bottom:50px;">

    <!-- Cover -->
    <div class="detail-cover cover-<?= $cls ?>" style="min-width:220px;width:260px;height:340px;flex-shrink:0;">
      <?php if (file_exists($img) && $b['image'] !== 'default.jpg'): ?>
        <img src="<?= $img ?>" alt="<?= htmlspecialchars($b['title']) ?>" style="width:100%;height:100%;object-fit:cover;">
      <?php else: ?>
        <span style="font-size:4rem;"><?= $emoji ?></span>
      <?php endif; ?>
    </div>

    <!-- Info -->
    <div class="detail-info" style="flex:1;min-width:260px;">
      <div class="breadcrumb">
        <a href="index.php">Books</a> /
        <a href="index.php?cat=<?= urlencode($b['category']) ?>"><?= htmlspecialchars($b['category']) ?></a>
      </div>

      <span class="cat-badge cat-<?= $cls ?>" style="display:inline-block;margin-bottom:10px;"><?= htmlspecialchars($b['category']) ?></span>
      <h1 style="font-family:'Playfair Display',serif;font-size:2rem;margin-bottom:6px;"><?= htmlspecialchars($b['title']) ?></h1>
      <div class="d-author" style="color:var(--gray);font-style:italic;margin-bottom:14px;">by <?= htmlspecialchars($b['author']) ?></div>
      <div class="d-price" style="font-size:2rem;font-weight:700;color:var(--teal);margin-bottom:14px;">SAR <?= number_format($b['price'], 2) ?></div>

      <?php if ($b['stock'] > 0): ?>
        <span class="stock-pill stock-in" style="display:inline-block;margin-bottom:16px;">✓ In Stock — <?= $b['stock'] ?> copies available</span>
      <?php else: ?>
        <span class="stock-pill stock-out" style="display:inline-block;margin-bottom:16px;">✕ Out of Stock</span>
      <?php endif; ?>

      <?= $msg ?>

      <?php if ($b['stock'] > 0): ?>
      <form method="post" style="margin-top:10px;" onsubmit="return validateForm()">
        <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px;">
          <label style="font-weight:700;font-size:0.8rem;text-transform:uppercase;color:var(--gray);">Quantity</label>
          <input type="number" name="quantity" value="1" min="1" max="<?= $b['stock'] ?>"
            style="width:70px;padding:8px;border:1.5px solid var(--pale-teal);border-radius:3px;font-size:1rem;text-align:center;">
        </div>
        <div style="display:flex;gap:12px;flex-wrap:wrap;">
          <button type="submit" name="add_cart" class="btn-brown">Add to Cart</button>
          <a href="cart.php" class="btn-outline-brown">View Cart</a>
        </div>
      </form>
      <?php else: ?>
        <a href="index.php" class="btn-outline-brown" style="margin-top:10px;display:inline-block;">← Browse Other Books</a>
      <?php endif; ?>
    </div>
  </div>

  <!-- Details Table -->
  <h2 style="font-family:'Playfair Display',serif;font-size:1.4rem;margin-bottom:16px;">Book Details</h2>
  <table style="width:100%;border-collapse:collapse;background:var(--white);border:1px solid var(--pale-teal);font-size:0.92rem;">
    <thead>
      <tr style="background:var(--teal);color:var(--teal-light);">
        <th style="padding:12px 18px;text-align:left;font-size:0.72rem;font-weight:700;letter-spacing:0.14em;text-transform:uppercase;width:160px;">Field</th>
        <th style="padding:12px 18px;text-align:left;font-size:0.72rem;font-weight:700;letter-spacing:0.14em;text-transform:uppercase;">Details</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ([
        ['Title',    $b['title']],
        ['Author',   $b['author']],
        ['Category', $b['category']],
        ['Price',    'SAR ' . number_format($b['price'], 2)],
        ['Stock',    $b['stock'] . ' copies'],
      ] as $i => [$lbl, $val]): ?>
      <tr style="background:<?= $i%2===0 ? 'var(--white)' : '#f0f8fb' ?>;">
        <td style="padding:12px 18px;font-weight:700;font-size:0.8rem;text-transform:uppercase;color:var(--gray);border-bottom:1px solid var(--teal-light);"><?= $lbl ?></td>
        <td style="padding:12px 18px;border-bottom:1px solid var(--teal-light);color:var(--gray);"><?= htmlspecialchars($val) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<!-- Help Button -->
<button onclick="document.getElementById('helpModal').style.display='flex'" 
  aria-label="Open help window"
  style="padding:20px 20px;font-size:1.2rem;background:#2e7d8c;color:#fff;border:none;border-radius:6px;cursor:pointer;">
  Help
</button>

<!-- Help Popup -->
<div id="helpModal" role="dialog" aria-modal="true" aria-label="Help window" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);justify-content:center;align-items:center;z-index:999;">
  <div style="background:#fff;padding:50px;max-width:650px;width:90%;border-radius:6px;">
    <h3>How to Order</h3>
    <p>1. Choose your quantity.<br>2. Click "Add to Cart".<br>3. Go to Cart and checkout.</p>
    <button onclick="document.getElementById('helpModal').style.display='none'">Close ✕</button>
  </div>
</div>


<script>
function validateForm() {
  const qty = document.querySelector('input[name="quantity"]').value;
  if (!qty || qty < 1) { alert('Please enter a valid quantity.'); return false; }
  return true;
}
</script>



<footer><p>© <?= date('Y') ?> <span>Kitab Store</span> — Books for Every Mind · Saudi Arabia</p></footer>
</body>
</html>


