-- ============================================================
--  Kitab Store — Database
--  Run in phpMyAdmin or: mysql -u root -p < database.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS book_store CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE book_store;

-- ── Admin ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS Admin (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50)  NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

-- ── Books ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS Books (
    book_id  INT AUTO_INCREMENT PRIMARY KEY,
    title    VARCHAR(150)  NOT NULL,
    author   VARCHAR(100)  NOT NULL,
    price    DECIMAL(10,2) NOT NULL,
    stock    INT           NOT NULL DEFAULT 0,
    image    VARCHAR(255)  DEFAULT 'default.jpg',
    category VARCHAR(50)   NOT NULL,
    admin_id INT,
    FOREIGN KEY (admin_id) REFERENCES Admin(admin_id)
);

-- ── Orders ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS Orders (
    order_id    INT,
    book_id     INT,
    quantity    INT           NOT NULL,
    total_price DECIMAL(10,2),
    date        DATETIME      DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (order_id, book_id),
    FOREIGN KEY (book_id) REFERENCES Books(book_id)
);

-- ── Customer Orders (extended) ───────────────────────────────
-- Stores full customer info per order number
CREATE TABLE IF NOT EXISTS CustomerOrders (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    order_id         INT          NOT NULL UNIQUE,
    customer_name    VARCHAR(255) NOT NULL,
    customer_email   VARCHAR(255) NOT NULL,
    customer_phone   VARCHAR(50),
    customer_address TEXT,
    total_amount     DECIMAL(10,2) NOT NULL,
    status           VARCHAR(50)  DEFAULT 'pending',
    created_at       DATETIME     DEFAULT CURRENT_TIMESTAMP
);

-- ── Admin account (password: admin) ───────────────────────
INSERT INTO Admin (username, password) VALUES
('admin', 1234)
ON DUPLICATE KEY UPDATE username = username;

-- ── Books (matching WebProject images) ───────────────────────
INSERT INTO Books (title, author, price, stock, image, category, admin_id) VALUES
-- Adult / Fiction
('The Midnight Library',                 'Matt Haig',                75.00, 15, 'The_midnight_library.jpg',                             'Adult',    1),
('Before the Coffee Gets Cold',          'Toshikazu Kawaguchi',      65.00, 12, 'Before_the_coffee_gets_cold.jpg',                      'Adult',    1),
('Spells, Strings and Forgotten Things', 'Breanne Randall',          70.00,  8, 'Spells_Strings_and_Forgotten_Things_-_A_Novel.jpg',    'Adult',    1),
('The Darkness Within Us',               'Tricia Levenseller',       68.00, 10, 'The_Darkness_Within_Us.jpg',                           'Adult',    1),
('The Little Prince',                    'Antoine de Saint-Exupery', 45.00, 20, 'The_little_prince.jpg',                                'Adult',    1),
('Think and Grow Rich',                  'Napoleon Hill',            55.00, 18, 'Think___grow_rich.jpg',                                'Adult',    1),
-- Children
('James and the Giant Peach',            'Roald Dahl',               50.00, 14, 'James_and_the_giant_peach.jpg',                        'Children', 1),
('Heidi',                                'Johanna Spyri',            40.00, 10, 'Heidi.jpg',                                            'Children', 1),
('Sly Fox and Red Hen',                  'Ladybird Readers',         30.00, 25, 'Sly_Fox_and_Red_Hen_-_Level_2__Ladybird_Readers_.jpg', 'Children', 1),
('First Nursery Rhymes - 10 Books Set',  'Various',                 120.00,  6, 'First_Nursery_Rhymes_-_10_Books_Set.jpg',              'Children', 1);
