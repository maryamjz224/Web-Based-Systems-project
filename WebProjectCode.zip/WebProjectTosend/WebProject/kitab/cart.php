<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update']))     { $pid = (int)$_POST['pid']; if (isset($_SESSION['cart'][$pid])) $_SESSION['cart'][$pid]['qty'] = max(1,(int)$_POST['quantity']); }
    if (isset($_POST['delete']))     { unset($_SESSION['cart'][(int)$_POST['pid']]); }
    if (isset($_POST['delete_all'])) { $_SESSION['cart'] = []; }
    header('Location: cart.php'); exit;
}

$cart  = $_SESSION['cart'] ?? [];
$total = array_sum(array_map(fn($i) => $i['price'] * $i['qty'], $cart));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Cart — Kitab Store</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<nav class="navbar">
  <a href="index.php" class="nav-logo"><span class="logo-icon">📚</span> Kitab Store</a>
  <ul class="nav-links">
    <li><a href="index.php">Books</a></li>
    <li><a href="contact.php">Contact</a></li>
    <li><a href="cart.php" class="nav-cart">🛒 Cart (<?= cart_count() ?>)</a></li>
  </ul>
</nav>

<div class="cart-wrap">
  <h1>Your Cart</h1>

  <?php if (empty($cart)): ?>
    <div class="alert alert-info">
      Your cart is empty. <a href="index.php" style="color:var(--brown);font-weight:700;">Browse Books →</a>
    </div>
  <?php else: ?>

  <table class="cart-tbl">
    <thead>
      <tr><th>Cover</th><th>Title</th><th>Price</th><th>Quantity</th><th>Subtotal</th><th>Remove</th></tr>
    </thead>
    <tbody>
    <?php foreach ($cart as $pid => $item):
      $img = 'images/' . $item['image'];
    ?>
    <tr>
      <td>
        <?php if (file_exists($img) && $item['image'] !== 'default.jpg'): ?>
          <img src="<?= $img ?>" alt="" style="width:46px;height:58px;object-fit:cover;border-radius:2px;">
        <?php else: ?><div class="cart-img-ph">📖</div><?php endif; ?>
      </td>
      <td><strong style="font-family:'Playfair Display',serif;font-size:0.95rem;"><?= htmlspecialchars($item['name']) ?></strong></td>
      <td>SAR <?= number_format($item['price'], 2) ?></td>
      <td>
        <form method="post" style="display:flex;gap:7px;align-items:center;">
          <input type="hidden" name="pid" value="<?= $pid ?>">
          <input type="number" name="quantity" value="<?= $item['qty'] ?>" min="1"
            style="width:58px;padding:6px 8px;border:1.5px solid var(--light-gray);border-radius:3px;font-size:0.88rem;text-align:center;">
          <button type="submit" name="update" class="btn-upd">Update</button>
        </form>
      </td>
      <td><strong>SAR <?= number_format($item['price'] * $item['qty'], 2) ?></strong></td>
      <td>
        <form method="post" onsubmit="return confirm('Remove this book?')">
          <input type="hidden" name="pid" value="<?= $pid ?>">
          <button type="submit" name="delete" class="btn-del">Remove</button>
        </form>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>

  <div class="cart-summary">
    <div class="cart-total">
      <span class="lbl">Order Total</span>
      <span class="amt">SAR <?= number_format($total, 2) ?></span>
    </div>
    <div class="cart-btns">
      <a href="index.php" class="btn-outline-brown">← Continue Shopping</a>
      <form method="post" onsubmit="return confirm('Clear cart?')" style="display:inline;">
        <button type="submit" name="delete_all" class="btn-del" style="padding:11px 18px;">Clear All</button>
      </form>
      <a href="checkout.php" class="btn-brown">Proceed to Checkout →</a>
    </div>
  </div>

  <?php endif; ?>
</div>

<footer><p>© <?= date('Y') ?> <span>Kitab Store</span> — Books for Every Mind · Saudi Arabia</p></footer>
</body>
</html>
