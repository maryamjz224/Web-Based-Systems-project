<?php
require_once '../config.php';
require_once 'auth_guard.php';

$cats = ['Adult', 'Children'];
$err  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title    = $conn->real_escape_string(trim($_POST['title']    ?? ''));
    $author   = $conn->real_escape_string(trim($_POST['author']   ?? ''));
    $cat      = $conn->real_escape_string(trim($_POST['category'] ?? ''));
    $price    = (float)($_POST['price']    ?? 0);
    $stock    = (int)($_POST['stock']      ?? 0);
    $admin_id = (int)$_SESSION['admin_id'];
    $image    = 'default.jpg';

    if (!empty($_FILES['image']['name'])) {
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
            $err = 'Invalid image type.';
        } elseif ($_FILES['image']['size'] > 5 * 1024 * 1024) {
            $err = 'Max image size is 5MB.';
        } else {
            $image = uniqid('book_', true) . '.' . $ext;
            move_uploaded_file($_FILES['image']['tmp_name'], '../images/' . $image);
        }
    }

    if (!$err && $title && $author && $cat && $price > 0) {
        $stmt = $conn->prepare("INSERT INTO Books (title,author,price,stock,image,category,admin_id) VALUES(?,?,?,?,?,?,?)");
        $stmt->bind_param('ssdissi', $title, $author, $price, $stock, $image, $cat, $admin_id);
        $stmt->execute();
        $stmt->close();
        header('Location: products.php?msg=added'); exit;
    } elseif (!$err) {
        $err = 'Please fill in all required fields.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Book — Kitab Admin</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="admin-layout">
  <div class="admin-sidebar">
    <a href="dashboard.php" class="sidebar-brand">📚 Kitab</a>
    <a href="dashboard.php">▣ Dashboard</a>
    <a href="products.php">◈ Books</a>
    <a href="add_product.php" class="active">+ Add Book</a>
    <a href="orders.php">◉ Orders</a>
    <a href="../index.php" target="_blank">↗ View Store</a>
    <a href="logout.php" class="logout">↩ Logout</a>
  </div>
  <div class="admin-main">
    <div class="admin-topbar">
      <h1>Add New Book</h1>
      <a href="products.php">← Back to Books</a>
    </div>
    <div class="admin-body">
      <?php if ($err): ?><div class="alert alert-danger"><?= htmlspecialchars($err) ?></div><?php endif; ?>
      <div class="admin-form-box">
        <form method="post" enctype="multipart/form-data">

          <div class="form-grp">
            <label>Book Title *</label>
            <input type="text" name="title" placeholder="e.g. The Midnight Library" required
              value="<?= htmlspecialchars($_POST['title'] ?? '') ?>">
          </div>

          <div class="form-grp">
            <label>Author *</label>
            <input type="text" name="author" placeholder="e.g. Matt Haig" required
              value="<?= htmlspecialchars($_POST['author'] ?? '') ?>">
          </div>

          <div class="form-row2">
            <div class="form-grp">
              <label>Category *</label>
              <select name="category" required>
                <option value="">Select category</option>
                <?php foreach ($cats as $c): ?>
                  <option value="<?= $c ?>" <?= (($_POST['category'] ?? '') === $c) ? 'selected' : '' ?>><?= $c ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-grp">
              <label>Price (SAR) *</label>
              <input type="number" name="price" step="0.01" min="0" placeholder="0.00" required
                value="<?= htmlspecialchars($_POST['price'] ?? '') ?>">
            </div>
          </div>

          <div class="form-grp">
            <label>Stock Quantity *</label>
            <input type="number" name="stock" min="0" placeholder="0" required
              value="<?= htmlspecialchars($_POST['stock'] ?? '') ?>">
          </div>

          <div class="form-grp">
            <label>Book Cover Image</label>
            <input type="file" name="image" accept="image/*"
              style="border:1px dashed var(--light-gray);padding:10px;width:100%;border-radius:3px;background:var(--cream);"
              onchange="prevImg(this)">
            <img id="pv" src="#" alt="Preview"
              style="max-width:120px;margin-top:10px;display:none;border-left:4px solid var(--brown);border-radius:2px;">
          </div>

          <div style="display:flex;gap:12px;margin-top:8px;flex-wrap:wrap;">
            <a href="products.php" class="btn-outline-brown">Cancel</a>
            <button type="submit" class="btn-brown">Add Book 📚</button>
          </div>

        </form>
      </div>
    </div>
  </div>
</div>
<script>
function prevImg(input) {
  const pv = document.getElementById('pv');
  if (input.files && input.files[0]) {
    const r = new FileReader();
    r.onload = e => { pv.src = e.target.result; pv.style.display = 'block'; };
    r.readAsDataURL(input.files[0]);
  }
}
</script>
</body>
</html>
