<?php
require_once '../config.php';
require_once 'auth_guard.php';

// Get all orders joined with customer info
$orders = $conn->query("
    SELECT co.order_id, co.customer_name, co.customer_email,
           co.customer_phone, co.total_amount, co.status, co.created_at
    FROM CustomerOrders co
    ORDER BY co.created_at DESC
")->fetch_all(MYSQLI_ASSOC);

$total_orders = count($orders);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Orders — Kitab Admin</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="admin-layout">
  <div class="admin-sidebar">
    <a href="dashboard.php" class="sidebar-brand">📚 Kitab</a>
    <a href="dashboard.php">▣ Dashboard</a>
    <a href="products.php">◈ Books</a>
    <a href="add_product.php">+ Add Book</a>
    <a href="orders.php" class="active">◉ Orders</a>
    <a href="../index.php" target="_blank">↗ View Store</a>
    <a href="logout.php" class="logout">↩ Logout</a>
  </div>
  <div class="admin-main">
    <div class="admin-topbar">
      <h1>Customer Orders</h1>
      <div class="tr"><?= $total_orders ?> order(s) total</div>
    </div>
    <div class="admin-body">
      <?php if (empty($orders)): ?>
        <div class="alert alert-info">No orders yet.</div>
      <?php else: ?>
      <table class="data-tbl">
        <thead>
          <tr><th>Order #</th><th>Customer</th><th>Email</th><th>Phone</th><th>Total (SAR)</th><th>Status</th><th>Date</th><th>Books</th></tr>
        </thead>
        <tbody>
        <?php foreach ($orders as $o):
          // Get order items
          $items = $conn->query("
              SELECT b.title, ord.quantity
              FROM Orders ord
              JOIN Books b ON b.book_id = ord.book_id
              WHERE ord.order_id = {$o['order_id']}
          ")->fetch_all(MYSQLI_ASSOC);
        ?>
        <tr>
          <td><strong>#<?= $o['order_id'] ?></strong></td>
          <td><?= htmlspecialchars($o['customer_name']) ?></td>
          <td style="color:var(--gray);font-size:0.82rem;"><?= htmlspecialchars($o['customer_email']) ?></td>
          <td style="color:var(--gray);font-size:0.82rem;"><?= htmlspecialchars($o['customer_phone'] ?: '—') ?></td>
          <td style="font-weight:700;color:var(--brown);">SAR <?= number_format($o['total_amount'], 2) ?></td>
          <td><span style="background:var(--cream);color:var(--brown);padding:3px 10px;font-size:0.72rem;font-weight:700;border-radius:2px;letter-spacing:0.1em;"><?= ucfirst(htmlspecialchars($o['status'])) ?></span></td>
          <td style="color:var(--gray);font-size:0.82rem;"><?= date('M j, Y', strtotime($o['created_at'])) ?></td>
          <td style="font-size:0.82rem;">
            <?php foreach ($items as $it): ?>
              <div style="color:var(--gray);"><?= htmlspecialchars($it['title']) ?> ×<?= $it['quantity'] ?></div>
            <?php endforeach; ?>
          </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <?php endif; ?>
    </div>
  </div>
</div>
</body>
</html>
