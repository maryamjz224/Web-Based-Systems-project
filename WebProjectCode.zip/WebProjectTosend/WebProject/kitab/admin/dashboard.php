<?php
require_once '../config.php';
require_once 'auth_guard.php';

$total_books  = $conn->query("SELECT COUNT(*) c FROM Books")->fetch_assoc()['c'];
$total_orders = $conn->query("SELECT COUNT(DISTINCT order_id) c FROM Orders")->fetch_assoc()['c'];
$total_rev    = $conn->query("SELECT COALESCE(SUM(total_price),0) s FROM Orders")->fetch_assoc()['s'];
$low_stock    = $conn->query("SELECT COUNT(*) c FROM Books WHERE stock <= 3")->fetch_assoc()['c'];

// Recent orders with customer info
$recent = $conn->query("
    SELECT co.order_id, co.customer_name, co.customer_email, co.total_amount, co.status, co.created_at
    FROM CustomerOrders co
    ORDER BY co.created_at DESC
    LIMIT 6
")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard — Kitab Admin</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="admin-layout">
  <div class="admin-sidebar">
    <a href="dashboard.php" class="sidebar-brand">📚 Kitab</a>
    <a href="dashboard.php" class="active">▣ Dashboard</a>
    <a href="products.php">◈ Books</a>
    <a href="add_product.php">+ Add Book</a>
    <a href="orders.php">◉ Orders</a>
    <a href="../index.php" target="_blank">↗ View Store</a>
    <a href="logout.php" class="logout">↩ Logout</a>
  </div>
  <div class="admin-main">
    <div class="admin-topbar">
      <h1>Dashboard</h1>
      <div class="tr">Welcome, <strong><?= htmlspecialchars($_SESSION['admin_name']) ?></strong> · <a href="logout.php">Logout</a></div>
    </div>
    <div class="admin-body">

      <div class="stats-row">
        <div class="stat-tile"><div class="sl">Total Books</div><div class="sv"><?= $total_books ?></div></div>
        <div class="stat-tile"><div class="sl">Total Orders</div><div class="sv"><?= $total_orders ?></div></div>
        <div class="stat-tile"><div class="sl">Revenue (SAR)</div><div class="sv"><?= number_format($total_rev, 0) ?></div></div>
        <div class="stat-tile" style="border-top-color:#EF5350;"><div class="sl">Low Stock (≤3)</div><div class="sv"><?= $low_stock ?></div></div>
      </div>

      <h3 style="font-family:'Playfair Display',serif;font-size:1.25rem;font-weight:600;margin-bottom:14px;">Recent Orders</h3>
      <?php if (empty($recent)): ?>
        <p style="color:var(--gray);">No orders yet.</p>
      <?php else: ?>
      <table class="data-tbl">
        <thead><tr><th>Order #</th><th>Customer</th><th>Email</th><th>Total (SAR)</th><th>Status</th><th>Date</th></tr></thead>
        <tbody>
        <?php foreach ($recent as $o): ?>
        <tr>
          <td><strong>#<?= $o['order_id'] ?></strong></td>
          <td><?= htmlspecialchars($o['customer_name']) ?></td>
          <td style="color:var(--gray);font-size:0.82rem;"><?= htmlspecialchars($o['customer_email']) ?></td>
          <td style="font-weight:700;color:var(--brown);">SAR <?= number_format($o['total_amount'], 2) ?></td>
          <td><span style="background:var(--cream);color:var(--brown);padding:3px 10px;font-size:0.72rem;font-weight:700;letter-spacing:0.1em;border-radius:2px;"><?= ucfirst(htmlspecialchars($o['status'])) ?></span></td>
          <td style="color:var(--gray);font-size:0.82rem;"><?= date('M j, Y', strtotime($o['created_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <?php endif; ?>

      <div style="margin-top:20px;"><a href="products.php" class="btn-brown">Manage Books →</a></div>
    </div>
  </div>
</div>
</body>
</html>
