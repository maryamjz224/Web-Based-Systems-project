<?php
require_once '../config.php';
require_once 'auth_guard.php';

// Delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['del'])) {
    $bid = (int)$_POST['bid'];
    $row = $conn->query("SELECT image FROM Books WHERE book_id=$bid")->fetch_assoc();
    if ($row && $row['image'] !== 'default.jpg') @unlink('../images/' . $row['image']);
    $conn->query("DELETE FROM Orders WHERE book_id=$bid");
    $conn->query("DELETE FROM Books WHERE book_id=$bid");
    header('Location: products.php?msg=deleted'); exit;
}

$search = trim($_GET['search'] ?? '');
$sql    = 'SELECT * FROM Books';
if ($search) {
    $s   = $conn->real_escape_string($search);
    $sql .= " WHERE title LIKE '%$s%' OR author LIKE '%$s%' OR category LIKE '%$s%'";
}
$sql  .= ' ORDER BY book_id DESC';
$books = $conn->query($sql)->fetch_all(MYSQLI_ASSOC);
$msg   = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Books — Kitab Admin</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="admin-layout">
  <div class="admin-sidebar">
    <a href="dashboard.php" class="sidebar-brand">📚 Kitab</a>
    <a href="dashboard.php">▣ Dashboard</a>
    <a href="products.php" class="active">◈ Books</a>
    <a href="add_product.php">+ Add Book</a>
    <a href="orders.php">◉ Orders</a>
    <a href="../index.php" target="_blank">↗ View Store</a>
    <a href="logout.php" class="logout">↩ Logout</a>
  </div>
  <div class="admin-main">
    <div class="admin-topbar">
      <h1>Manage Books</h1>
      <a href="add_product.php" class="btn-brown" style="padding:8px 18px;font-size:0.78rem;">+ Add New Book</a>
    </div>
    <div class="admin-body">
      <?php if ($msg === 'deleted'): ?><div class="alert alert-danger">Book deleted.</div><?php endif; ?>
      <?php if ($msg === 'added'):   ?><div class="alert alert-success">Book added successfully!</div><?php endif; ?>
      <?php if ($msg === 'updated'): ?><div class="alert alert-success">Book updated!</div><?php endif; ?>

      <form method="get" class="search-row">
        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search by title, author or category...">
        <button type="submit">Search</button>
        <?php if ($search): ?><a href="products.php" class="btn-outline-brown" style="padding:9px 16px;">Clear</a><?php endif; ?>
      </form>

      <p style="font-size:0.79rem;color:var(--gray);margin-bottom:14px;">
        <?= count($books) ?> book(s)<?= $search ? ' for "<strong>' . htmlspecialchars($search) . '</strong>"' : '' ?>
      </p>

      <table class="data-tbl">
        <thead>
          <tr><th>Cover</th><th>#</th><th>Title</th><th>Author</th><th>Category</th><th>Price (SAR)</th><th>Stock</th><th>Actions</th></tr>
        </thead>
        <tbody>
        <?php if (empty($books)): ?>
          <tr><td colspan="8" style="text-align:center;padding:36px;color:var(--gray);">No books found.</td></tr>
        <?php else: ?>
        <?php foreach ($books as $b):
          $img = '../images/' . $b['image'];
          $cls = CAT_CSS[$b['category']] ?? 'adult';
        ?>
        <tr>
          <td><?php if (file_exists($img) && $b['image'] !== 'default.jpg'): ?><img src="<?= $img ?>" alt="" style="width:36px;height:46px;object-fit:cover;border-radius:2px;"><?php else: ?><div class="img-ph">📖</div><?php endif; ?></td>
          <td style="color:var(--gray);">#<?= $b['book_id'] ?></td>
          <td style="font-family:'Playfair Display',serif;font-size:0.95rem;font-weight:600;"><?= htmlspecialchars($b['title']) ?></td>
          <td style="color:var(--gray);font-style:italic;font-size:0.82rem;"><?= htmlspecialchars($b['author']) ?></td>
          <td><span class="cat-badge cat-<?= $cls ?>" style="font-size:0.62rem;"><?= htmlspecialchars($b['category']) ?></span></td>
          <td style="font-weight:700;">SAR <?= number_format($b['price'], 2) ?></td>
          <td><span style="<?= $b['stock'] <= 3 ? 'color:#B71C1C;font-weight:700;' : '' ?>"><?= $b['stock'] ?></span></td>
          <td style="display:flex;gap:6px;align-items:center;">
            <a href="edit_product.php?id=<?= $b['book_id'] ?>" class="btn-edit">Edit</a>
            <form method="post" onsubmit="return confirm('Delete this book?')">
              <input type="hidden" name="bid" value="<?= $b['book_id'] ?>">
              <button type="submit" name="del" class="btn-del-sm">Delete</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</body>
</html>
