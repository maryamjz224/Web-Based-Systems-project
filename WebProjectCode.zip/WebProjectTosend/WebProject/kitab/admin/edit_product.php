<?php
require_once '../config.php';
require_once 'auth_guard.php';

$id = (int)($_GET['id'] ?? 0);
$b  = $conn->query("SELECT * FROM Books WHERE book_id=$id")->fetch_assoc();
if (!$b) { header('Location: products.php'); exit; }

$cats = ['Adult', 'Children', 'Fiction', 'History', 'Educational'];
$err  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title  = $conn->real_escape_string(trim($_POST['title']    ?? ''));
    $author = $conn->real_escape_string(trim($_POST['author']   ?? ''));
    $cat    = $conn->real_escape_string(trim($_POST['category'] ?? ''));
    $price  = (float)($_POST['price'] ?? 0);
    $stock  = (int)($_POST['stock']   ?? 0);
    $image  = $b['image'];

    if (!empty($_FILES['image']['name'])) {
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
            $err = 'Invalid image type.';
        } elseif ($_FILES['image']['size'] > 5 * 1024 * 1024) {
            $err = 'Max image size is 5MB.';
        } else {
            if ($image !== 'default.jpg') @unlink('../images/' . $image);
            $image = uniqid('book_', true) . '.' . $ext;
            move_uploaded_file($_FILES['image']['tmp_name'], '../images/' . $image);
        }
    }

    if (!$err && $title && $author && $cat && $price > 0) {
        $stmt = $conn->prepare("UPDATE Books SET title=?,author=?,price=?,stock=?,image=?,category=? WHERE book_id=?");
        $stmt->bind_param('ssdissi', $title, $author, $price, $stock, $image, $cat, $id);
        $stmt->execute();
        $stmt->close();
        header('Location: products.php?msg=updated'); exit;
    } elseif (!$err) {
        $err = 'Please fill in all required fields.';
    }
}

$img = '../images/' . $b['image'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Book — Kitab Admin</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="admin-layout">
  <div class="admin-sidebar">
    <a href="dashboard.php" class="sidebar-brand">📚 Kitab</a>
    <a href="dashboard.php">▣ Dashboard</a>
    <a href="products.php" class="active">◈ Books</a>
    <a href="add_product.php">+ Add Book</a>
    <a href="orders.php">◉ Orders</a>
    <a href="../index.php" target="_blank">↗ View Store</a>
    <a href="logout.php" class="logout">↩ Logout</a>
  </div>
  <div class="admin-main">
    <div class="admin-topbar">
      <h1>Edit Book #<?= $id ?></h1>
      <a href="products.php">← Back</a>
    </div>
    <div class="admin-body">
      <?php if ($err): ?><div class="alert alert-danger"><?= htmlspecialchars($err) ?></div><?php endif; ?>
      <div class="admin-form-box">
        <form method="post" enctype="multipart/form-data">

          <div class="form-grp">
            <label>Book Title *</label>
            <input type="text" name="title" required value="<?= htmlspecialchars($b['title']) ?>">
          </div>
          <div class="form-grp">
            <label>Author *</label>
            <input type="text" name="author" required value="<?= htmlspecialchars($b['author']) ?>">
          </div>

          <div class="form-row2">
            <div class="form-grp">
              <label>Category *</label>
              <select name="category" required>
                <?php foreach ($cats as $c): ?>
                  <option value="<?= $c ?>" <?= $b['category'] === $c ? 'selected' : '' ?>><?= $c ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-grp">
              <label>Price (SAR) *</label>
              <input type="number" name="price" step="0.01" min="0" required value="<?= $b['price'] ?>">
            </div>
          </div>

          <div class="form-grp">
            <label>Stock Quantity *</label>
            <input type="number" name="stock" min="0" required value="<?= $b['stock'] ?>">
          </div>

          <div class="form-grp">
            <label>Book Cover (leave blank to keep current)</label>
            <?php if (file_exists($img) && $b['image'] !== 'default.jpg'): ?>
              <div style="margin-bottom:10px;">
                <img src="<?= $img ?>" style="max-width:100px;border-left:4px solid var(--brown);">
                <p style="font-size:0.74rem;color:var(--gray);margin-top:4px;">Current cover</p>
              </div>
            <?php endif; ?>
            <input type="file" name="image" accept="image/*"
              style="border:1px dashed var(--light-gray);padding:10px;width:100%;border-radius:3px;"
              onchange="prevImg(this)">
            <img id="pv" src="#" style="max-width:100px;margin-top:10px;display:none;border-left:4px solid var(--brown);">
          </div>

          <div style="display:flex;gap:12px;margin-top:8px;">
            <a href="products.php" class="btn-outline-brown">Cancel</a>
            <button type="submit" class="btn-brown">Update Book 📚</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<script>
function prevImg(i) {
  const p = document.getElementById('pv');
  if (i.files[0]) { const r = new FileReader(); r.onload = e => { p.src = e.target.result; p.style.display = 'block'; }; r.readAsDataURL(i.files[0]); }
}
</script>
</body>
</html>
