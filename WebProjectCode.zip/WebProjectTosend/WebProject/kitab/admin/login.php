<?php
require_once '../config.php';
if (!empty($_SESSION['admin_id'])) { header('Location: dashboard.php'); exit; }

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim($_POST['username'] ?? '');
    $p = trim($_POST['password'] ?? '');

    $result = $conn->query("SELECT * FROM admin WHERE username='$u' AND `password`='$p'");
    $admin  = $result ? $result->fetch_assoc() : null;

    if ($admin) {
        $_SESSION['admin_id']   = $admin['admin_id'];
        $_SESSION['admin_name'] = $admin['username'];
        header('Location: dashboard.php');
        exit;
    } else {
        $err = 'Invalid username or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login — Kitab</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="admin-login-page">
  <div class="login-box">
    <div class="brand">📚 Kitab</div>
    <div class="sub">Admin Panel</div>
    <?php if ($err): ?><div class="alert alert-danger"><?= htmlspecialchars($err) ?></div><?php endif; ?>
    <form method="post">
      <div class="form-grp"><label>Username</label><input type="text" name="username" placeholder="admin" required autofocus></div>
      <div class="form-grp"><label>Password</label><input type="password" name="password" placeholder="••••••••" required></div>
      <button type="submit" class="btn-brown" style="width:100%;margin-top:8px;">Sign In →</button>
    </form>
  
    <p style="text-align:center;margin-top:6px;font-size:0.76rem;"><a href="../index.php" style="color:var(--brown);">← Back to Store</a></p>
  </div>
</div>
</body>
</html>
